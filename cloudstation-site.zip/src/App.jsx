import React from "react";
import { BrowserRouter, Routes, Route, Link, NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Send, Users, Megaphone, Gift, LifeBuoy } from "lucide-react";

// Minimal UI wrappers (no external UI kit)
const Button = ({ className = "", children, ...props }) => (
  <button className={`rounded-2xl px-4 py-2 ${className}`} {...props}>{children}</button>
);
const Card = ({ className = "", children }) => (
  <div className={`rounded-3xl border border-gray-200 shadow-sm bg-white ${className}`}>{children}</div>
);
const CardHeader = ({ className = "", children }) => <div className={`p-4 ${className}`}>{children}</div>;
const CardTitle = ({ className = "", children }) => <h3 className={`text-lg font-semibold ${className}`}>{children}</h3>;
const CardContent = ({ className = "", children }) => <div className={`p-4 pt-0 ${className}`}>{children}</div>;

/**
 * CloudStation – Marketing Site (multi‑page)
 * Pages: Home (hero), Advertising, Jobs, Refer & Earn, Support
 * Theme: matches the pitch deck palette via CSS vars
 * Constraints: rotating machine video bg, NO pricing/numbers, NO product showcases, NO founder/team
 */

const BRAND = {
  name: "CloudStation",
  colors: {
    primary: "#10BCE4",
    primaryDark: "#0AA7C9",
    accent: "#22E3B4",
    ink: "#101828",
    night: "#0A0F1A",
    soft: "#F5FAFF",
  },
  cta: { label: "Talk to Sales", href: "/advertising" },
  hero: {
    title: "Charge up. Reach customers where they stand.",
    subtitle:
      "CloudStation powers on‑the‑go phone charging with screen placements built for hyper‑local advertising—QR, promos and data capture without the guesswork.",
  },
};

function Layout({ children }) {
  return (
    <div className="min-h-screen" style={{
      "--brand": BRAND.colors.primary,
      "--brand-dark": BRAND.colors.primaryDark,
      "--accent": BRAND.colors.accent,
      "--ink": BRAND.colors.ink,
      "--night": BRAND.colors.night,
      "--soft": BRAND.colors.soft,
      color: "var(--ink)",
    }}>
      <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/75 border-b border-gray-200">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <div className="h-8 w-8 rounded-xl" style={{ background: "linear-gradient(135deg, var(--brand), var(--accent))" }} aria-hidden />
            <span>{BRAND.name}</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <NavItem to="/advertising" label="Advertising" />
            <NavItem to="/jobs" label="Jobs" />
            <NavItem to="/refer" label="Refer & Earn" />
            <NavItem to="/support" label="Support" />
            <Button className="h-9" style={{ backgroundColor: "var(--brand)", color: "white" }}>
              <Link to={BRAND.cta.href}>{BRAND.cta.label}</Link>
            </Button>
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t border-gray-200">
        <div className="mx-auto max-w-6xl px-4 py-10 text-sm text-gray-600 flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <Link className="hover:opacity-80" to="/support">Contact</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function NavItem({ to, label }) {
  return (
    <NavLink to={to} className={({ isActive }) => `hover:opacity-90 ${isActive ? "font-semibold text-[color:var(--brand)]" : ""}`}>
      {label}
    </NavLink>
  );
}

// ---- Hero with rotating machine video ---------------------------------------
function Hero() {
  return (
    <section className="relative overflow-hidden" aria-labelledby="hero-heading">
      <div className="absolute inset-0">
        <video className="h-full w-full object-cover" autoPlay loop muted playsInline poster="/video-poster.jpg">
          <source src="/rotating-machine.webm" type="video/webm" />
          <source src="/rotating-machine.mp4" type="video/mp4" />
        </video>
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 80% at 50% 0%, rgba(16,188,228,0.28), transparent 60%), linear-gradient(180deg, rgba(10,15,26,0.78), rgba(10,15,26,0.78))" }} />
      </div>
      <style>{`@media (prefers-reduced-motion: reduce){ video{ display:none } }`}</style>
      <div className="relative mx-auto max-w-6xl px-4 py-24 md:py-36 grid md:grid-cols-2 gap-10 items-center">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <h1 id="hero-heading" className="text-4xl md:text-6xl font-bold leading-tight text-white">{BRAND.hero.title}</h1>
          <p className="mt-4 text-lg text-white/80">{BRAND.hero.subtitle}</p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <Button className="h-11 px-6" style={{ backgroundColor: "var(--brand)", color: "white" }}>
              <Link to={BRAND.cta.href} className="flex items-center gap-2">
                {BRAND.cta.label} <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button className="h-11 px-6 border border-white text-white hover:bg-white/10" style={{ background: "transparent" }}>
              <Link to="/refer">Refer & Earn</Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// ---- Advertising Page --------------------------------------------------------
function AdvertisingPage() {
  const pillars = [
    { icon: <Megaphone className="h-6 w-6" aria-hidden />, title: "Hyper‑local placements", desc: "Screens meet people exactly where they need a charge—venues and events with real foot traffic." },
    { icon: <Send className="h-6 w-6" aria-hidden />, title: "QR to action", desc: "Drive scans to promos, menus, signup forms or app deep‑links in a tap—no guesswork." },
    { icon: <Users className="h-6 w-6" aria-hidden />, title: "Consent‑first capture", desc: "Build opt‑in SMS/email lists for remarketing—simple and privacy‑aware." },
  ];
  return (
    <Layout>
      <Hero />
      <section className="mx-auto max-w-6xl px-4 py-16 md:py-24">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold">Advertising that meets customers in the moment</h2>
          <p className="mt-2 text-gray-600 max-w-2xl mx-auto">Tell the right story at the right spot. Pair on‑screen creative with QR, promos and simple capture flows—no pricing tables, no hassle.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {pillars.map((p, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center gap-3">
                <div className="p-2 rounded-xl" style={{ backgroundColor: "var(--soft)", color: "var(--brand)" }} aria-hidden>
                  {p.icon}
                </div>
                <CardTitle className="text-lg">{p.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{p.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-8">
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>What makes us different</CardTitle></CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Nightlife‑native placements with creative built for ambient, low‑light environments.</li>
                <li>Dynamic QR prompts that can rotate by daypart or event type.</li>
                <li>Lightweight performance snapshots you can actually read—no complex dashboards.</li>
                <li>Zero clutter: no public pricing tables and no distracting product catalogs.</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Built for quick launches</CardTitle></CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Self‑serve brief: goals, markets, creative link—done.</li>
                <li>Template‑ready specs for motion/video and static art.</li>
                <li>Privacy‑aware list capture (email/SMS) with clear consent language.</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 pb-24">
        <Card>
          <CardHeader><CardTitle>Start a campaign</CardTitle></CardHeader>
          <CardContent>
            <form className="grid md:grid-cols-2 gap-4">
              <Field label="Company" />
              <Field label="Website" placeholder="https://" />
              <Field label="Contact name" />
              <Field type="email" label="Work email" placeholder="you@company.com" />
              <Field label="City / Market" />
              <div className="md:col-span-2">
                <label className="block text-sm font-medium">Campaign notes</label>
                <textarea rows={4} className="mt-1 w-full rounded-xl border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]" placeholder="Objectives, timing, creative links" />
              </div>
              <div className="md:col-span-2">
                <Button className="rounded-2xl" style={{ backgroundColor: "var(--brand)", color: "white" }}>Submit</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </section>
    </Layout>
  );
}

// ---- Jobs Page ---------------------------------------------------------------
function JobsPage() {
  const values = [
    "Move fast, stay safe",
    "Own the outcome",
    "Simple beats complex",
    "Be venue‑first",
    "Data with consent",
  ];
  return (
    <Layout>
      <section className="mx-auto max-w-6xl px-4 py-20 md:py-28">
        <h1 className="text-4xl md:text-5xl font-bold">Join {BRAND.name}</h1>
        <p className="mt-3 text-gray-600 max-w-2xl">We build charging and advertising experiences people actually want to use. No fluff.</p>
        <div className="mt-10 grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Open Roles</CardTitle></CardHeader>
            <CardContent>
              <ul className="space-y-2 text-gray-700">
                <li>Field Operations (General Application)</li>
                <li>Sales & Partnerships (General Application)</li>
                <li>Creative & Content (General Application)</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Our values</CardTitle></CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                {values.map((v) => (<li key={v}>{v}</li>))}
              </ul>
            </CardContent>
          </Card>
        </div>
        <Card className="mt-8">
          <CardHeader><CardTitle>Apply now</CardTitle></CardHeader>
          <CardContent>
            <form className="grid md:grid-cols-2 gap-4">
              <Field label="Full name" />
              <Field type="email" label="Email" />
              <Field label="Role of interest" placeholder="Field Ops / Sales / Creative" />
              <Field label="Location" />
              <div className="md:col-span-2">
                <label className="block text-sm font-medium">Why you?</label>
                <textarea rows={4} className="mt-1 w-full rounded-xl border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]" placeholder="Short note (no resume upload here)" />
              </div>
              <div className="md:col-span-2">
                <Button className="rounded-2xl" style={{ backgroundColor: "var(--brand)", color: "white" }}>Submit application</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </section>
    </Layout>
  );
}

// ---- Refer & Earn Page -------------------------------------------------------
function ReferPage() {
  const steps = [
    { title: "Submit a lead", text: "Share a venue or partner you know. Keep details simple." },
    { title: "We review", text: "Our team validates fit and reaches out." },
    { title: "Install", text: "If it moves forward, we handle deployment with the venue." },
    { title: "Get rewarded", text: "We'll share compensation details directly upon approval." },
  ];
  return (
    <Layout>
      <section className="mx-auto max-w-6xl px-4 py-20 md:py-28">
        <h1 className="text-4xl md:text-5xl font-bold flex items-center gap-3"><Gift className="h-8 w-8" style={{ color: "var(--brand)" }} /> Refer & Earn</h1>
        <p className="mt-3 text-gray-600 max-w-2xl">Know a venue or organizer that should partner with {BRAND.name}? Send them our way.</p>
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <Card>
            <CardHeader><CardTitle>How it works</CardTitle></CardHeader>
            <CardContent>
              <ol className="list-decimal pl-5 space-y-2 text-gray-700">
                {steps.map((s) => (<li key={s.title}><span className="font-medium">{s.title}:</span> {s.text}</li>))}
              </ol>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Submit a referral</CardTitle></CardHeader>
            <CardContent>
              <form className="grid md:grid-cols-2 gap-4">
                <Field label="Your name" />
                <Field type="email" label="Your email" />
                <Field label="Venue / Partner name" />
                <Field label="City" />
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium">Contact at venue (if any)</label>
                  <input className="mt-1 w-full rounded-xl border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]" placeholder="Name, phone or email" />
                </div>
                <div className="md:col-span-2">
                  <Button className="rounded-2xl" style={{ backgroundColor: "var(--brand)", color: "white" }}>Send referral</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </Layout>
  );
}

// ---- Support Page ------------------------------------------------------------
function SupportPage() {
  return (
    <Layout>
      <section className="mx-auto max-w-6xl px-4 py-20 md:py-28">
        <h1 className="text-4xl md:text-5xl font-bold flex items-center gap-3"><LifeBuoy className="h-8 w-8" style={{ color: "var(--brand)" }} /> Support</h1>
        <p className="mt-3 text-gray-600 max-w-2xl">We're streamlining support. In the meantime, drop a quick note and we'll follow up.</p>
        <Card className="mt-8">
          <CardHeader><CardTitle>Message us</CardTitle></CardHeader>
          <CardContent>
            <form className="grid md:grid-cols-2 gap-4">
              <Field label="Name" />
              <Field type="email" label="Email" />
              <div className="md:col-span-2">
                <label className="block text-sm font-medium">Message</label>
                <textarea rows={4} className="mt-1 w-full rounded-xl border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]" placeholder="How can we help?" />
              </div>
              <div className="md:col-span-2">
                <Button className="rounded-2xl" style={{ backgroundColor: "var(--brand)", color: "white" }}>Send</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </section>
    </Layout>
  );
}

// ---- Small form field component ---------------------------------------------
function Field({ label, type = "text", placeholder = "" }) {
  return (
    <div>
      <label className="block text-sm font-medium">{label}</label>
      <input type={type} className="mt-1 w-full rounded-xl border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]" placeholder={placeholder} />
    </div>
  );
}

// ---- App (Routes) ------------------------------------------------------------
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <Hero />
              <section className="mx-auto max-w-6xl px-4 py-16">
                <div className="grid md:grid-cols-3 gap-6">
                  {["Venue‑first", "Frictionless", "Privacy‑aware"].map((k) => (
                    <Card key={k}>
                      <CardHeader className="flex items-center gap-3">
                        <div className="p-2 rounded-xl" style={{ backgroundColor: "var(--soft)", color: "var(--brand)" }} aria-hidden>
                          <CheckCircle2 className="h-5 w-5" />
                        </div>
                        <CardTitle className="text-lg">{k}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600">{k === "Venue‑first"
                          ? "We design installs that fit the flow of your space."
                          : k === "Frictionless"
                          ? "Scan, charge and go—no complicated steps."
                          : "We only collect what users opt into and keep it simple."}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            </Layout>
          }
        />
        <Route path="/advertising" element={<AdvertisingPage />} />
        <Route path="/jobs" element={<JobsPage />} />
        <Route path="/refer" element={<ReferPage />} />
        <Route path="/support" element={<SupportPage />} />
      </Routes>
    </BrowserRouter>
  );
}
