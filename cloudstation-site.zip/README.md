# CloudStation Site

Multi-page marketing site (React + Vite + Tailwind).

## Run locally
```bash
npm install
npm run dev
```

Put your hero video in `public/` as:
- `rotating-machine.mp4` (and optionally `rotating-machine.webm`)
- Optional: `video-poster.jpg`

## Deploy (Vercel)
1. Push this folder to GitHub.
2. On vercel.com: **New Project** → **Import Git Repository** → select this repo.
3. Framework: **Vite**. Build: `npm run build`. Output: `dist`.
4. Ensure `vercel.json` is included (SPA routing). Deploy.
